extends CharacterBody2D
class_name EnemyExploration

@export var speed := 40
@export var chase_speed := 100
@export var return_speed := 50
@export var patrol_zone_path : NodePath
@export var max_chase_distance := 200.0

@export var enemy_id : String

enum State { PATROL, CHASE, RETURN }
var state = State.PATROL

var last_direction:String = "down"
var invulnerable:bool = false

var player: Node2D = null
var spawn_position: Vector2
var direction := Vector2.ZERO
var change_dir_timer := 0.0

var patrol_center : Vector2
var patrol_size : Vector2

@onready var sprite: AnimatedSprite2D = $EnemySprites
@onready var body_shape: CollisionShape2D = $Cuerpo
var body_half_size : Vector2

func _ready():
	add_to_group("enemies")
	spawn_position = global_position
	
	var patrol_zone = get_node(patrol_zone_path)
	var shape = patrol_zone.get_node("CollisionShape2D").shape
	
	if body_shape.shape is RectangleShape2D:
		body_half_size = body_shape.shape.size / 2
	
	if shape is RectangleShape2D:
		patrol_size = shape.size
		patrol_center = patrol_zone.global_position
	

func _physics_process(delta):
	match state:
		State.PATROL:
			patrol(delta)
			
		State.CHASE:
			if player:
				# Si el jugador sale del área de patrulla, dejar de perseguir
				if not is_inside_patrol_zone(player.global_position):
					player = null
					state = State.RETURN
				else:
					chase()
			else:
				state = State.RETURN
		State.RETURN:
			return_to_spawn()
	

	move_and_slide()
	keep_inside_zone()
	update_animation()

# ==============================
# COMPORTAMIENTOS
# ==============================

func patrol(delta):
	change_dir_timer -= delta
	
	if change_dir_timer <= 0:
		direction = Vector2(
			randf_range(-1,1),
			randf_range(-1,1)
		).normalized()
		change_dir_timer = randf_range(1.0, 2.5)
	
	velocity = direction * speed

func chase():
	if player:
		direction = (player.global_position - global_position).normalized()
		velocity = direction * chase_speed
	else:
		state = State.RETURN

func is_inside_patrol_zone(pos: Vector2) -> bool:
	var half = patrol_size / 2
	
	return (
		pos.x >= patrol_center.x - half.x and
		pos.x <= patrol_center.x + half.x and
		pos.y >= patrol_center.y - half.y and
		pos.y <= patrol_center.y + half.y
	)

func return_to_spawn():
	if global_position.distance_to(spawn_position) < 5:
		state = State.PATROL
		return
	
	direction = (spawn_position - global_position).normalized()
	velocity = direction * return_speed

# ==============================
# LIMITES
# ==============================

func keep_inside_zone():
	var patrol_half = patrol_size / 2
	
	global_position.x = clamp(
		global_position.x,
		patrol_center.x - patrol_half.x + body_half_size.x,
		patrol_center.x + patrol_half.x - body_half_size.x
	)
	
	global_position.y = clamp(
		global_position.y,
		patrol_center.y - patrol_half.y + body_half_size.y,
		patrol_center.y + patrol_half.y - body_half_size.y
	)
# ==============================
# ANIMACIONES
# ==============================

func update_animation():
	if velocity == Vector2.ZERO:
		velocity = Vector2.ZERO
		update_animation_sprite("idle")
		return
	
	#comprobar si se mueve horizontal o vertical
	if abs(velocity.x) > abs(velocity.y):
		#mov horizontal, ahora calcular el sentido
		if velocity.x > 0:
			last_direction = "right"
		else:
			last_direction = "left"
	else:
		if velocity.y > 0:
			last_direction = "down"
		else:
			last_direction = "up"
	
	if abs(velocity.length()) > return_speed + 1:
		update_animation_sprite("run")
	else:
		update_animation_sprite("walk")
		

func update_animation_sprite(estado):
	sprite.play(estado + "_" + last_direction)
# ==============================
# DETECCIÓN
# ==============================
func _on_detection_area_body_entered(body):
	if body.is_in_group("player"):
		player = body
		state = State.CHASE


func _on_combat_area_body_entered(body):
	Global.get_player_position()
	if body.is_in_group("player"):
		call_deferred("_start_battle_safe")
		

func start_cooldown():
	$CombatArea.monitoring = false
	modulate.a = 0.4
	
	await get_tree().create_timer(5.0).timeout
	
	$CombatArea.monitoring = true
	modulate.a = 1.0

func _start_battle_safe():
	Global.last_battle_enemy_id = enemy_id
	Global.returning_from_battle = true
	Global.start_battle()
