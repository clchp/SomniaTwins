extends Node2D

@export var track:String
@onready var jugador:Player = $Player

func _ready():
	Global.escena_actual = get_tree().current_scene.scene_file_path
	AudioPlayer.play_music_level(track)
	
	if Global.returning_from_battle:
		jugador.global_position = Global.posicion_jugador
		if Global.last_battle_enemy_id != "":
			_apply_enemy_cooldown(Global.last_battle_enemy_id)
		Global.returning_from_battle = false
		Global.last_battle_enemy_id = ""
	
	if NavigationManager.spawn_trigger_tag != null:
		_on_scene_spawn(NavigationManager.spawn_trigger_tag)
		NavigationManager.spawn_trigger_tag = null

		
func _on_scene_spawn(destination_tag: String):
	var trigger_path:String  = "Transicion/Trigger" + destination_tag
	var trigger = get_node(trigger_path) as TransitionTrigger
	NavigationManager.trigger_player_spawn(trigger.spawn.global_position, trigger.spawn_direction)

func _apply_enemy_cooldown(id:String):
	for enemy in get_tree().get_nodes_in_group("enemies"):
		if enemy.enemy_id == id:
			enemy.start_cooldown()
			break
