class_name DatosPartida
extends Resource

@export var escena_actual:String
@export var posicion_jugador:Vector2
@export var dato1:int #ejemplos
