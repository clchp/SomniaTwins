extends Node
class_name GlobalManager

const SETTINGS_PATH := "user://settings.cfg"

# Verificar si está el jugador en un dialogo
var dialogue_active: bool = false
var dialogue_cooldown: bool = false

# Verificar si está en combate
var in_combat: bool = false

# Ubicacion del jugador
var escena_actual:String
var posicion_jugador:Vector2

# Resoluciones disponibles
const RESOLUCIONES = [
	Vector2i(1280, 720),
	Vector2i(1920, 1080)
]

# Variables globales
var resolution_index: int = 0
var fullscreen: bool = true
var master_volume: float = 1.0
var music_volume: float = 1.0
var sfx_volume: float = 1.0

# Estado del juego
enum GameState {
	EXPLORATION,
	BATTLE,
	MENU
}
var current_state : GameState = GameState.EXPLORATION

var last_battle_enemy_id : String = ""
var returning_from_battle := false

func start_battle():
	get_tree().change_scene_to_file("res://DataCombat/Tests/battle_test.tscn")

func end_battle():
	get_tree().change_scene_to_file(escena_actual)

# Funcion Ready

func _ready():
	load_settings()
	AudioServer.set_bus_volume_db(0, linear_to_db(master_volume))
	DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_RESIZE_DISABLED, true)
	DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)


# Funcion para hallar la ubicacion del jugador

func get_player_position():
	var jugadores = get_tree().get_nodes_in_group("player")
	if jugadores.size() > 0:
		var jugador = jugadores[0]
		posicion_jugador = jugador.global_position
	else:
		posicion_jugador = Vector2.ZERO 


# Cargar y Guardar Ajustes

func save_settings():
	var config = ConfigFile.new()
	config.set_value("audio", "master", master_volume)
	# config.set_value("audio", "music", music_volume)
	# config.set_value("audio", "sfx", sfx_volume)
	config.set_value("video", "fullscreen", fullscreen)
	config.set_value("video", "resolution_index", resolution_index)
	config.save(SETTINGS_PATH)

func load_settings():
	var config = ConfigFile.new()
	if config.load(SETTINGS_PATH) != OK:
		return

	master_volume = config.get_value("audio", "master", 1.0)
	# music_volume = config.get_value("audio", "music", 1.0)
	# sfx_volume = config.get_value("audio", "sfx", 1.0)

	fullscreen = config.get_value("video", "fullscreen", true)
	resolution_index = config.get_value("video", "resolution_index", 0)
