extends CanvasLayer

@onready var panel = $Panel

# -------- MAIN PANEL --------
@onready var main_panel = $Panel/MainPanel
@onready var continue_btn = $Panel/MainPanel/VBoxContainer/Continuar
@onready var settings_btn = $Panel/MainPanel/VBoxContainer/Ajustes
@onready var mainmenu_btn = $Panel/MainPanel/VBoxContainer/SalirMenu
@onready var quit_btn = $Panel/MainPanel/VBoxContainer/SalirJuego

# -------- SETTINGS PANEL --------

@onready var settings_panel = $Panel/SettingsPanel

@onready var slider_master : HSlider = $Panel/SettingsPanel/Botones/VolumenGeneral
#@onready var slider_music  : HSlider = $VBoxContainer/VolumenMusica
#@onready var slider_sfx    : HSlider = $VBoxContainer/VolumenSFX
@onready var toggle_fullscreen : CheckButton = $Panel/SettingsPanel/Botones/Fullscreen
@onready var option_resolution : OptionButton = $Panel/SettingsPanel/Botones/Resolution
@onready var btn_volver : Button = $Panel/SettingsPanel/Volver

func _ready():
	hide()
	process_mode = Node.PROCESS_MODE_ALWAYS
	conectar_senales_main()
	conectar_senales_settings()
	configurar_sliders()
	configurar_resoluciones()
	cargar_settings()
	
	_show_main_panel()



func _unhandled_input(event):
	if event.is_action_pressed("pause"):
		# Si estás en ajustes, vuelve al menú principal
		if settings_panel.visible:
			_show_main_panel()
		else:
			toggle()


func toggle():
	var new_state = !get_tree().paused
	get_tree().paused = new_state
	visible = new_state
	_set_buttons_enabled(new_state)

	if new_state:
		_show_main_panel()

func conectar_senales_main():
	continue_btn.pressed.connect(_on_continue_pressed)
	settings_btn.pressed.connect(_on_settings_pressed)
	mainmenu_btn.pressed.connect(_on_mainmenu_pressed)
	quit_btn.pressed.connect(_on_quit_pressed)
# ==============================
# CAMBIO ENTRE PANELES
# ==============================

func _show_main_panel():
	settings_panel.hide()
	main_panel.show()
	

func _show_settings_panel():
	main_panel.hide()
	settings_panel.show()


# ==============================
# CONTROL DE BOTONES
# ==============================

func _set_buttons_enabled(state: bool):
	continue_btn.disabled = !state
	settings_btn.disabled = !state
	mainmenu_btn.disabled = !state
	quit_btn.disabled = !state
	
	slider_master.editable = state
	toggle_fullscreen.disabled = !state
	option_resolution.disabled = !state
	btn_volver.disabled = !state

# ==============================
# BOTONES PRINCIPALES
# ==============================

func _on_continue_pressed():
	toggle()

func _on_settings_pressed():
	_show_settings_panel()

func _on_mainmenu_pressed():
	get_tree().paused = false
	get_tree().change_scene_to_file("res://Escenas/Principales/main_menu.tscn")

func _on_quit_pressed():
	get_tree().quit()



func configurar_sliders():
	slider_master.min_value = 0.0
	slider_master.max_value = 1.0
	slider_master.step = 0.01
	
	#slider_music.min_value = 0.0
	#slider_music.max_value = 1.0
	#slider_music.step = 0.01
	
	#slider_sfx.min_value = 0.0
	#slider_sfx.max_value = 1.0
	#slider_sfx.step = 0.01


func configurar_resoluciones():
	option_resolution.clear()  # IMPORTANTE
	for r in Global.RESOLUCIONES:
		option_resolution.add_item(str(r.x) + "x" + str(r.y))

func conectar_senales_settings():
	slider_master.value_changed.connect(_on_master_changed)
	#slider_music.value_changed.connect(_on_music_changed)
	#slider_sfx.value_changed.connect(_on_sfx_changed)
	toggle_fullscreen.toggled.connect(_on_fullscreen_toggled)
	option_resolution.item_selected.connect(_on_resolution_selected)
	btn_volver.pressed.connect(_on_volver_pressed)

# -------------------------
# AUDIO
# -------------------------

func _on_master_changed(value):
	AudioServer.set_bus_volume_db(0, linear_to_db(value))
	Global.master_volume = slider_master.value
	Global.save_settings()

func _on_music_changed(value):
	AudioServer.set_bus_volume_db(1, linear_to_db(value))
	Global.save_settings()

func _on_sfx_changed(value):
	AudioServer.set_bus_volume_db(2, linear_to_db(value))
	Global.save_settings()


# -------------------------
# VIDEO
# -------------------------

func _on_fullscreen_toggled(enabled):
	if enabled:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
	Global.fullscreen = toggle_fullscreen.button_pressed
	Global.save_settings()

func _on_resolution_selected(index):
	Global.resolution_index = index
	DisplayServer.window_set_size(Global.RESOLUCIONES[index])
	var screen_size = DisplayServer.screen_get_usable_rect()
	var window_size = DisplayServer.window_get_size()
	var pos = screen_size.position + (screen_size.size - window_size) / 2
	DisplayServer.window_set_position(pos)
	Global.resolution_index = option_resolution.selected
	Global.save_settings()


# -------------------------
# GUARDAR / CARGAR
# -------------------------

func cargar_settings():
	Global.load_settings()
	
	# AUDIO
	slider_master.value = Global.master_volume
	#slider_music.value  = config.get_value("audio", "music", 1.0)
	#slider_sfx.value    = config.get_value("audio", "sfx", 1.0)
	
	AudioServer.set_bus_volume_db(0, linear_to_db(slider_master.value))
	#AudioServer.set_bus_volume_db(1, linear_to_db(slider_music.value))
	#AudioServer.set_bus_volume_db(2, linear_to_db(slider_sfx.value))
	
	# VIDEO
	toggle_fullscreen.button_pressed = Global.fullscreen
	_on_fullscreen_toggled(Global.fullscreen)
	
	option_resolution.select(Global.resolution_index)
	_on_resolution_selected(Global.resolution_index)


# -------------------------
# VOLVER
# -------------------------

func _on_volver_pressed():
	_show_main_panel()
