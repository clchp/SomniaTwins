extends Control

@export var track:String

@onready var btn_nuevo = $VBoxContainer/Nuevo
@onready var btn_cargar = $VBoxContainer/Cargar
@onready var btn_ajustes = $VBoxContainer/Ajustes
@onready var btn_creditos = $VBoxContainer/Creditos
@onready var btn_salir = $VBoxContainer/Salir

func _ready():
	TransitionScreen.presentationMainMenu()
	AudioPlayer.play_music_level(track)
	btn_nuevo.pressed.connect(_on_nuevo_pressed,4)
	btn_cargar.pressed.connect(_on_cargar_pressed,4)
	btn_ajustes.pressed.connect(_on_ajustes_pressed,4)
	btn_salir.pressed.connect(_on_salir_pressed,4)
	btn_creditos.pressed.connect(_on_creditos_pressed,4)

func _on_nuevo_pressed():
	print("Nuevo juego iniciado")
	TransitionScreen.transition()
	await TransitionScreen.on_transition_finished
	get_tree().change_scene_to_file("res://Escenas/Places/inicio.tscn")

func _on_cargar_pressed():
	print("Cargar partida")
	TransitionScreen.transition()
	await TransitionScreen.on_transition_finished
	GameControl.cargar_partida()

func _on_ajustes_pressed():
	print("Abrir ajustes")
	TransitionScreen.transition()
	await TransitionScreen.on_transition_finished
	get_tree().change_scene_to_file("res://Escenas/Principales/ajustes.tscn")

func _on_creditos_pressed():
	print("Abrir créditos")
	TransitionScreen.transition()
	await TransitionScreen.on_transition_finished
	get_tree().change_scene_to_file("res://Escenas/Principales/creditos.tscn")

func _on_salir_pressed():
	TransitionScreen.transition()
	await TransitionScreen.on_transition_finished
	get_tree().quit()
