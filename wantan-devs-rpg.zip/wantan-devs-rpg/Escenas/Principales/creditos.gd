extends Control

func _ready():
	pass

func _on_salir_pressed():
	TransitionScreen.transition()
	await TransitionScreen.on_transition_finished
	get_tree().change_scene_to_file("res://Escenas/Principales/main_menu.tscn")
	
func _unhandled_input(event):
	if event.is_action_pressed("pause"):
		_on_salir_pressed()
