class_name CameraWantanDevs
extends Camera2D

#var base_size = Vector2i(480, 270)
#
#func _ready():
	#update_limits()
#
#func _notification(what):
	#if what == NOTIFICATION_WM_SIZE_CHANGED:
		#update_limits()
#
#func update_limits():
	#var screen_size = get_viewport().size
	## Calcula cuánto más grande es la pantalla respecto a la base
	#var extra = screen_size - base_size
	## Ajusta los límites de la cámara para cubrir todo
	#limit_left = -extra.x / 2
	#limit_top = -extra.y / 2
	#limit_right = base_size.x + extra.x / 2
	#limit_bottom = base_size.y + extra.y / 2
