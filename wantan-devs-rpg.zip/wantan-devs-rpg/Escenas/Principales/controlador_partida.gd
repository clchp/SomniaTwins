class_name ControladorPartida
extends Node

@export var partida_guardada:DatosPartida

var _ruta:String = "user://datagame.tres"

func _ready():
	if partida_guardada == null:
		partida_guardada = DatosPartida.new()


func guardar_partida():
	partida_guardada.escena_actual = Global.escena_actual
	Global.get_player_position()
	partida_guardada.posicion_jugador = Global.posicion_jugador
	ResourceSaver.save(partida_guardada,_ruta)

func cargar_partida():
	if ResourceLoader.exists(_ruta):
		partida_guardada = load(_ruta)
		Global.escena_actual = partida_guardada.escena_actual
		Global.posicion_jugador = partida_guardada.posicion_jugador
		get_tree().change_scene_to_file(Global.escena_actual)
		
		await get_tree().process_frame
		var jugadores = get_tree().get_nodes_in_group("player")
		if jugadores.size() > 0:
			jugadores[0].global_position = Global.posicion_jugador
